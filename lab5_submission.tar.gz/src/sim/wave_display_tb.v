module wave_display_tb ();
    reg clk;
    reg reset;
    reg [10:0] x;  // [0..1279]
    reg [9:0]  y; // [0..1023]
    reg valid;
    reg [7:0] read_value;
    reg read_index;
    wire [8:0] read_address;
    wire valid_pixel;
    wire [7:0] r;
    wire [7:0] g;
    wire [7:0] b;
    
    wave_display wave_dis1 (
        .clk(clk),
        .reset(reset),
        .x(x),
        .y(y),
        .valid(valid),
        .read_value(read_value),
        .read_index(read_index),
        .read_address(read_address),
        .valid_pixel(valid_pixel),
        .r(r),
        .g(g),
        .b(b)
    );
    
    initial clk = 0;
    always #5 clk = ~clk;
    
    initial begin
        reset = 1;
        x = 0;
        y = 0;
        valid = 0;
        read_value = 0;
        read_index = 0;
        #10
        reset = 0;
        
        
        //invalid region x[10:9] = 00;
        valid = 1;
        x = 11'b000_00000000;
        y = 10'b000_00000000;
        read_value = 8'd50;
        #10
        $display("Test 1, valid_pixel == 0: %b", valid_pixel);
        
        //invalid region x[10:9] == 11;
        x = 11'b110_00000000;
        y = 10'b000_00000000;
        #10
        $display("Test 2, valid_pixel == 0: %b", valid_pixel);
        
        //invalid region bottom half y[9] == 1;
        x = 11'b001_00000000;
        y = 10'b010_00000000;
        #10
        $display("Test 3, valid_pixel == 0: %b", valid_pixel);

        // valid region, check address
        x = 11'b001_00000100;
        y = 10'b000_00000000;
        read_index = 0;
        #10
        $display("Test 4, read_address == {0, 0_0000010}, %b", read_address);
        
        // check for ram latency
        x = 11'b001_00000000; //addr changes
        read_value = 8'd60;
        #10
        x = 11'b001_00000001; // save curr
        #10
        x = 11'b001_00000010; // addr changes : prev <= curr
        read_value = 8'd80;
        #10
        x = 11'b001_00000011; // save curr 
        
        y = 10'b0_010000100;
        #10
        #10
        $display("valid_pixel == 1: %b", valid_pixel);
        
        // check out of bounds
        y = 10'b0_000000000;
        #10
        $display("valid_pixel == 0: %b", valid_pixel);
        #10
        $finish;
       
    end

endmodule
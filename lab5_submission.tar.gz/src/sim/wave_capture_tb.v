module wave_capture_tb();
    reg clk;
    reg reset;
    reg new_sample_ready;
    reg [15:0] new_sample_in;
    reg wave_display_idle;

    wire [8:0] write_address;
    wire write_enable;
    wire [7:0] write_sample;
    wire read_index;

    wave_capture waveCap (
        .clk(clk),
        .reset(reset),
        .new_sample_ready(new_sample_ready),
        .new_sample_in(new_sample_in),
        .wave_display_idle(wave_display_idle),
        .write_address(write_address),
        .write_enable(write_enable),
        .write_sample(write_sample),
        .read_index(read_index)
    ) ;
    
    initial clk = 0;
    always #5 clk = ~clk;
    
    integer i;
    
    initial begin
        reset = 1;
        new_sample_ready = 0;
        new_sample_in = 0;
        wave_display_idle = 0;
        #10
        reset = 0;
        
        // ARMED, no zero crossing
        new_sample_ready = 1;
        new_sample_in = 16'h0100; //positive 
        #10
        new_sample_in = 16'h0200; //positive
        #10
        $display("Test 1, write_enable == 0: %b", write_enable);
        
        // ARMED to ACTIVE
        new_sample_in = 16'hFF00; //negative
        #10;
        new_sample_in = 16'h0100; //positive
        #10
        $display("Test 2, write_enable == 1: %b", write_enable);
        $display("Test 2a write_address == 0: %h", write_address);
        
        //ACTIVE to WAIT and write 256 samples
        for (i = 0; i < 256; i = i + 1) begin
            new_sample_in = 16'h0100;
            #10;
            $display ("counter %d, write_addr %h, write_en %b, write_sample %h",
                i, write_address, write_enable, write_sample);
        end
        new_sample_ready = 0;
        $display("Test 3, write_enable %b", write_enable);
        
        //WAIT to ARMED
        $display("initial index %b", read_index);
        wave_display_idle = 1;
        #10;
        $display("after flip index: %b", read_index);
        wave_display_idle = 0;
        #10;
        
        //write_sample conversion is correct
        new_sample_ready = 1;
        new_sample_in = 16'hff00;
        #10;
        new_sample_in = 16'h0100;
        #10;
        $display("write_sample == 1: %b", write_sample);
        new_sample_in = 16'hff00;
        #10;
        $display("write_sample == 0: %b", write_sample);
        #10;
        $finish;
    end

endmodule